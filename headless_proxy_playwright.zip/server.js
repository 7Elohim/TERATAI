const express = require('express');
const { chromium } = require('playwright');

const app = express();
const PORT = process.env.PORT || 3000;

app.get('/render', async (req, res) => {
  const targetUrl = req.query.url;

  if (!targetUrl || !/^https?:\/\//.test(targetUrl)) {
    return res.status(400).send('URL tidak valid. Gunakan ?url=https://...');
  }

  try {
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    await page.goto(targetUrl, { waitUntil: 'networkidle' });
    const content = await page.content();
    await browser.close();

    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(content);
  } catch (err) {
    console.error("Error:", err.message);
    res.status(500).send("Gagal merender halaman.");
  }
});

app.listen(PORT, () => {
  console.log(`Headless proxy berjalan di http://localhost:${PORT}`);
});